int A();
int main()
{
  return A();
}
