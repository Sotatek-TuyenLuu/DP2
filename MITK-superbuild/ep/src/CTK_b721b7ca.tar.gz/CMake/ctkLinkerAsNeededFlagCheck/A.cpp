int B();
int A()
{
  return B();
}
