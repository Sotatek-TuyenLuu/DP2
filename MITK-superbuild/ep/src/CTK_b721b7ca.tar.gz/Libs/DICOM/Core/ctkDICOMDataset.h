#ifndef CTK_DICOM_DATASET_H
#define CTK_DICOM_DATASET_H
#if defined _MSC_VER
  #pragma message ( "Deprecated header ctkDICOMItem.h included. Please use ctkDICOMItem.h!" )
#elif defined __GNUC__
  #warning "Deprecated header ctkDICOMItem.h included. Please use ctkDICOMItem.h!"
#endif
#include "ctkDICOMItem.h"
#endif

