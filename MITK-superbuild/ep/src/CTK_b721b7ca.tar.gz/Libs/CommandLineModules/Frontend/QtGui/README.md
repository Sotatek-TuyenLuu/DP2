Qt Gui Frontend    {#CommandLineModulesFrontendQtGui_Page}
===============

\internal This page is best viewed in its [Doxygen processed]
(http://www.commontk.org/docs/html/CommandLineModulesFrontendQtGui_Page.html) form. \endinternal

The Qt Gui front-end uses a customizable XML stylesheet to transform the raw XML module
description into Qt .ui file. For details about the configuration possibilities of the GUI
generation process see the ctkCmdLineModuleFrontendQtGui class.

See the \ref CommandLineModulesFrontendQtGui_API module for the API documentation.
