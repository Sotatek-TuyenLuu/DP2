Qt WebKit Frontend (experimental)    {#CommandLineModulesFrontendQtWebKit_Page}
=================================

\internal This page is best viewed in its [Doxygen processed]
(http://www.commontk.org/docs/html/CommandLineModulesFrontendQtWebKit_Page.html) form. \endinternal

This front-end uses an XML stylesheet to transform the raw XML description of a module
into a HTML document and uses Qt WebKit to render this document inside a Qt widget.

The front-end is experimental and serves as a *proof-of-concept*, see also the
ctkCmdLineModuleFrontendQtWebKit class.

See the \ref CommandLineModulesFrontendQtWebKit_API module for the API documentation.
