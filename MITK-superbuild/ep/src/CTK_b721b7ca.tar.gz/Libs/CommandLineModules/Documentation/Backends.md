Backends    {#CommandLineModulesBackEnds_Page}
========

Here is a list of available back-ends:

- \subpage CommandLineModulesBackendFunctionPointer_Page
- \subpage CommandLineModulesBackendLocalProcess_Page
